@protocol AnemoneEventHandler
-(void)reloadTheme;
@end